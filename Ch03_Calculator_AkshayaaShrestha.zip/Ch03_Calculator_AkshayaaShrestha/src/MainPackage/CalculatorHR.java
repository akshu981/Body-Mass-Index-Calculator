
package MainPackage;

import java.text.NumberFormat;
import java.util.Locale;
import java.awt.Color;


public class CalculatorHR {
    
    final int BASE_NUM=200;
    final int INTENSITY_BASE= 100;
    
    private int targetHeartRate;
    private int intensity;
    private Color ColorIntensity;

    public CalculatorHR(int iAge, int intensity) {
        this.targetHeartRate= (BASE_NUM-iAge)*intensity/INTENSITY_BASE;
        this.intensity = intensity;
        setColorIntensity(intensity);
    }

    public int getTargetHeartRate() {
        return targetHeartRate;
    }

    public void setTargetHeartRate(int targetHeartRate) {
        this.targetHeartRate = targetHeartRate;
    }

    public int getIntensity() {
        return intensity;
    }

    public void setIntensity(int intensity) {
        this.intensity = intensity;
    }
    
    public String toString()
    {
        NumberFormat format= NumberFormat.getInstance();
        format.setMaximumFractionDigits(2);
        return "Target Heart rate: "+ format.format(targetHeartRate);
    }

    public Color getColorIntensity() {
        return ColorIntensity;
    }
    
    private void setColorIntensity(int intensity) //sets color according to the output heart rate
    {
        if(intensity<=50)
        {
            ColorIntensity= Color.CYAN;
        }
        
        if(intensity>50 && intensity<=75 )
        {
            ColorIntensity= Color.blue;
        }
        
        if(intensity>75)
        {
            ColorIntensity= Color.RED; 
        }
    }
    }
    
    

