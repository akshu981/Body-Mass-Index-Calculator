
package MainPackage;

import java.text.DecimalFormat;
import java.util.Locale;
import java.awt.Color;

public class CalculatorBMI {
    final int INCHES_FEET_INDEX = 12;
    final int BMI_CONSTANT= 703;
    
    private int iFeet;
    private int iInches;
    private double dBMI;
    
    private Color ColorIntensity;
    private int iWeight;
    private int iHeight;
    
    private String Comment;
    
    public CalculatorBMI(int iFeet, int iInches, int iWeight) {
        this.iFeet = iFeet;
        this.iInches = iInches;
        this.iWeight = iWeight;
        
        this.iHeight= INCHES_FEET_INDEX * iFeet + iInches;
        this.dBMI= (((double)iWeight / ((double)iHeight*iHeight))*(double)BMI_CONSTANT); //to prevent losing precision, every attribute should be double
        
        setColorIntensity();
    }

    public int getiFeet() {
        return iFeet;
    }

    public void setiFeet(int iFeet) {
        this.iFeet = iFeet;
    }

    public int getiInches() {
        return iInches;
    }

    public void setiInches(int iInches) {
        this.iInches = iInches;
    }

    public String getComment() { //used in UI_Form class to display comment
        return Comment;
    }
    
    public double getdBMI() {
        return dBMI;
    }

    public void setdBMI(double dBMI) {
        this.dBMI = dBMI;
    }

    public Color getColorIntensity() {
        return ColorIntensity;
    }

    public void setColorIntensity() {
         if(dBMI<18.5)
        {
            ColorIntensity= Color.ORANGE;
            Comment="You are underweight. Consider a diet with more caloric intake. ";
        }
        
        if(dBMI>=18.5 && dBMI<25 )
        {
            ColorIntensity= Color.GREEN;
            Comment="Your BMI is in normal range! ";
        }
        
        if(dBMI>=25 && dBMI<30)
        {
            ColorIntensity= Color.blue; 
            Comment="Consider lowering your caloric intake. You need to lose some weight. ";
        }
        
        if(dBMI>=30)
        {
            ColorIntensity= Color.RED; 
            Comment="You must change your lifestyle and lose weight to stay healthy. ";
        }
    }

    public String toString()
    {
        DecimalFormat dformat= new DecimalFormat("#0.00");
        return "Your BMI(Body Mass Index): "+ dformat.format(dBMI);
    }
    
    public int getiWeight() {
        return iWeight;
    }

    public void setiWeight(int iWeight) {
        this.iWeight = iWeight;
    }

    public int getiHeight() {
        return iHeight;
    }

    public void setiHeight(int iHeight) {
        this.iHeight = iHeight;
    }
    
    
    
    
    
}
