
package MainPackage;

import AuxPackage.AuxValidator;


public class UI_Form extends javax.swing.JFrame {

    public UI_Form() {
        initComponents();
        
        //for calculating Heart rate
        TextAge.setText(null); //puts a blank space for the value in text box
        lblAgeError.setVisible(false); //hides the error message at first
        lblIntensity.setText(SlidIntensity.getValue()+ "%"); //sets value of intensity level in terms of percentage
        lblOutput.setText(null); 
        lblOutput.setVisible(false);
        
        //for calculating BMI
        TextWeight.setText(null);
        lblWeightError.setVisible(false); //sets the error message blank at first
        lblComment_Label.setVisible(false);
        
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        tpnlMainTabPanel = new javax.swing.JTabbedPane();
        pnlHR = new javax.swing.JPanel();
        lblAge_Label = new javax.swing.JLabel();
        lblIntensityLabel = new javax.swing.JLabel();
        SlidIntensity = new javax.swing.JSlider();
        lblIntensity = new javax.swing.JLabel();
        TextAge = new javax.swing.JTextField();
        lblAgeError = new javax.swing.JLabel();
        lblOutput = new javax.swing.JLabel();
        pnlBMI = new javax.swing.JPanel();
        lblHeight_Label = new javax.swing.JLabel();
        lblWeight_Label = new javax.swing.JLabel();
        CboFeet = new javax.swing.JComboBox<>();
        CboInches = new javax.swing.JComboBox<>();
        TextWeight = new javax.swing.JTextField();
        lblBMI_Label = new javax.swing.JLabel();
        lblComment_Label = new javax.swing.JLabel();
        lblWeightError = new javax.swing.JLabel();
        menuMainMenu = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        ItemExit = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lblAge_Label.setText("Enter your age: ");

        lblIntensityLabel.setText("Intensity: ");

        SlidIntensity.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                SlidIntensityStateChanged(evt);
            }
        });

        lblIntensity.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lblIntensity.setText("Intensity percentage: ");

        TextAge.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextAgeActionPerformed(evt);
            }
        });
        TextAge.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                TextAgeKeyReleased(evt);
            }
        });

        lblAgeError.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lblAgeError.setForeground(new java.awt.Color(255, 0, 0));
        lblAgeError.setText("Age verification goes there");

        lblOutput.setText("Heart Rate");

        javax.swing.GroupLayout pnlHRLayout = new javax.swing.GroupLayout(pnlHR);
        pnlHR.setLayout(pnlHRLayout);
        pnlHRLayout.setHorizontalGroup(
            pnlHRLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlHRLayout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(pnlHRLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlHRLayout.createSequentialGroup()
                        .addGroup(pnlHRLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblAge_Label)
                            .addComponent(lblIntensityLabel))
                        .addGap(24, 24, 24)
                        .addGroup(pnlHRLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlHRLayout.createSequentialGroup()
                                .addComponent(SlidIntensity, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(33, 33, 33)
                                .addComponent(lblIntensity, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(114, Short.MAX_VALUE))
                            .addGroup(pnlHRLayout.createSequentialGroup()
                                .addComponent(TextAge, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblAgeError, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addGroup(pnlHRLayout.createSequentialGroup()
                        .addComponent(lblOutput, javax.swing.GroupLayout.PREFERRED_SIZE, 654, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        pnlHRLayout.setVerticalGroup(
            pnlHRLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlHRLayout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addGroup(pnlHRLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lblIntensity)
                    .addGroup(pnlHRLayout.createSequentialGroup()
                        .addGroup(pnlHRLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblAge_Label)
                            .addComponent(TextAge, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblAgeError))
                        .addGap(46, 46, 46)
                        .addGroup(pnlHRLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(SlidIntensity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblIntensityLabel))))
                .addGap(40, 40, 40)
                .addComponent(lblOutput, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(47, Short.MAX_VALUE))
        );

        tpnlMainTabPanel.addTab("Heart Rate Calculator", pnlHR);

        lblHeight_Label.setText("Height (feet/ inches): ");

        lblWeight_Label.setText("Enter weight: ");

        CboFeet.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "3", "4", "5", "6", "7", "8", "9", "10" }));
        CboFeet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CboFeetActionPerformed(evt);
            }
        });

        CboInches.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11" }));
        CboInches.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CboInchesActionPerformed(evt);
            }
        });

        TextWeight.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextWeightActionPerformed(evt);
            }
        });
        TextWeight.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                TextWeightKeyReleased(evt);
            }
        });

        lblBMI_Label.setText("Your BMI (Body Mass Index): ");

        lblComment_Label.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lblComment_Label.setText("Comment on BMI");

        lblWeightError.setText("Weight Error");

        javax.swing.GroupLayout pnlBMILayout = new javax.swing.GroupLayout(pnlBMI);
        pnlBMI.setLayout(pnlBMILayout);
        pnlBMILayout.setHorizontalGroup(
            pnlBMILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlBMILayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlBMILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlBMILayout.createSequentialGroup()
                        .addComponent(lblBMI_Label, javax.swing.GroupLayout.PREFERRED_SIZE, 252, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(pnlBMILayout.createSequentialGroup()
                        .addGroup(pnlBMILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(pnlBMILayout.createSequentialGroup()
                                .addComponent(lblWeight_Label)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(TextWeight, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(pnlBMILayout.createSequentialGroup()
                                .addComponent(lblHeight_Label)
                                .addGap(18, 18, 18)
                                .addComponent(CboFeet, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(pnlBMILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlBMILayout.createSequentialGroup()
                                .addGap(38, 38, 38)
                                .addComponent(CboInches, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(pnlBMILayout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(lblWeightError, javax.swing.GroupLayout.DEFAULT_SIZE, 457, Short.MAX_VALUE)
                                .addContainerGap())))
                    .addComponent(lblComment_Label, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        pnlBMILayout.setVerticalGroup(
            pnlBMILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlBMILayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlBMILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblHeight_Label)
                    .addComponent(CboFeet, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CboInches, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(84, 84, 84)
                .addGroup(pnlBMILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblWeight_Label)
                    .addComponent(TextWeight, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblWeightError))
                .addGap(63, 63, 63)
                .addComponent(lblBMI_Label)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblComment_Label)
                .addContainerGap(90, Short.MAX_VALUE))
        );

        tpnlMainTabPanel.addTab("BMI Calculator", pnlBMI);

        jMenu1.setText("File");

        ItemExit.setText("Exit");
        ItemExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ItemExitActionPerformed(evt);
            }
        });
        jMenu1.add(ItemExit);
        ItemExit.getAccessibleContext().setAccessibleName("ItemExit");

        menuMainMenu.add(jMenu1);

        setJMenuBar(menuMainMenu);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addComponent(tpnlMainTabPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 732, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(40, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addComponent(tpnlMainTabPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 385, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(51, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ItemExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ItemExitActionPerformed
        System.exit(0); //tab that exits application window
    }//GEN-LAST:event_ItemExitActionPerformed

    private void TextAgeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextAgeActionPerformed
        
    }//GEN-LAST:event_TextAgeActionPerformed

    
    private void SlidIntensityStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_SlidIntensityStateChanged
        int i= SlidIntensity.getValue(); // keep the slided value in integer i
        String desc = "Selected intensity: "+ i+ "%"; 
        lblIntensity.setText(desc); //sets the percentage of intensity level
        CalculateHR(); //performs the method so that when intensity level changes, heart rate also changes
        
    }//GEN-LAST:event_SlidIntensityStateChanged
       
            
    private void CalculateHR() //calculates heart rate
    {
        if (ValidateAge()) 
        {
        int iAge= Integer.parseInt(TextAge.getText());
        int iIntensity= SlidIntensity.getValue();
        CalculatorHR cal= new CalculatorHR( iAge, iIntensity);
        
        lblOutput.setForeground(cal.getColorIntensity());
        lblOutput.setText(cal.toString()); //sets the heart rate
        lblOutput.setVisible(true); //displays heart rate
        }
        else
        {
            lblOutput.setText(null); //sets target rate blank when age is invalid
        }
    }
    
     private void CalculateBMI() //calculates body mass index
    {
        
        if (ValidateWeight()) 
        {
        int iWeight= Integer.parseInt(TextWeight.getText());
        
        String sFeet= CboFeet.getSelectedItem().toString(); //puts the string input in variable sFeet
        int iFeet= Integer.parseInt(sFeet); 
        
        String sInches= CboInches.getSelectedItem().toString();
        int iInches= Integer.parseInt(sInches);
        
        CalculatorBMI calBMI= new CalculatorBMI( iFeet, iInches, iWeight);
        
        //displays color of comment according to the BMI obtained 
        lblComment_Label.setForeground(calBMI.getColorIntensity());
        
        //displays BMI value 
        lblBMI_Label.setText(calBMI.toString());
        
        //displays visibility of BMI obtained and comment
        lblBMI_Label.setVisible(true);
        lblComment_Label.setVisible(true);
        
        String ObjforComment= calBMI.getComment(); //instantiate object to use method in another class
        lblComment_Label.setText(ObjforComment); //sets comment to be displayed according to the data
        
        }
        else
        {
            lblBMI_Label.setText(null); //sets BMI blank when age is invalid
        }
    }
    
    private boolean ValidateWeight()
    {
        String sWeight= TextWeight.getText();
        String sErr= "Please provide a valid integer between 20 and 500.";
        
        if (AuxValidator.isInt(sWeight))
        {
        int iWeight= Integer.parseInt(sWeight);
        if (iWeight<20)
        {
         String error = "The entered integer is too small. "+ sErr;
         lblWeightError.setText(error);
         lblWeightError.setVisible(true);
         TextWeight.setBackground(new java.awt.Color(255, 102, 102));
         return false;       
        }
        
        else if(iWeight>500)
        {
         String error= "The entered integer is too large. "+ sErr;
         lblWeightError.setText(error);
         lblWeightError.setVisible(true); 
         TextWeight.setBackground(new java.awt.Color(255, 102, 102));
         return false;
        }
        
        else
        {
         lblWeightError.setText(null);
         lblWeightError.setVisible(false);
         TextWeight.setBackground(new java.awt.Color(255, 255, 255));
         return true;
        }
        
        }
        else
        {
         //display error message
         lblWeightError.setText(sErr);
         lblWeightError.setVisible(true);
         TextWeight.setBackground(new java.awt.Color(255, 102, 102));
         return false;
        }
        
    }
      
    
    private boolean ValidateAge()
    {
        //validate user input
        
        String sInput= TextAge.getText();
        String sErr= "Please provide a valid integer between 3 and 200.";
        if (AuxValidator.isInt(sInput))
        {
         //validate the range
         int iAge= Integer.parseInt(sInput);
         if (iAge<3)
             
        {
         String e= "Age is too small. "+ sErr;
         lblAgeError.setText(e);
         lblAgeError.setVisible(true);
         TextAge.setBackground(new java.awt.Color(255, 102, 102));
         return false;
        }
         
         else if (iAge>200)
        {
         String e= "Age is too large. "+ sErr;
         lblAgeError.setText(e);
         lblAgeError.setVisible(true); 
         TextAge.setBackground(new java.awt.Color(255, 102, 102));
         return false;
        }
         
         else
        {
         lblAgeError.setText(null);
         lblAgeError.setVisible(false);
         TextAge.setBackground(new java.awt.Color(255, 255, 255));
         return true;
        }
            
        }
        
        else
        {
         //display error message
         lblAgeError.setText(sErr);
         lblAgeError.setVisible(true);
         TextAge.setBackground(new java.awt.Color(255, 102, 102));
         return false;
        }
    }
            
    private void TextAgeKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TextAgeKeyReleased
        
         CalculateHR();   
         CalculateBMI();
    }//GEN-LAST:event_TextAgeKeyReleased

    private void CboFeetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CboFeetActionPerformed
        CalculateBMI();
    }//GEN-LAST:event_CboFeetActionPerformed

    private void CboInchesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CboInchesActionPerformed
        CalculateBMI();
    }//GEN-LAST:event_CboInchesActionPerformed

    private void TextWeightActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextWeightActionPerformed
        
    }//GEN-LAST:event_TextWeightActionPerformed

    private void TextWeightKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TextWeightKeyReleased
        CalculateBMI(); 
    }//GEN-LAST:event_TextWeightKeyReleased


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> CboFeet;
    private javax.swing.JComboBox<String> CboInches;
    private javax.swing.JMenuItem ItemExit;
    private javax.swing.JSlider SlidIntensity;
    private javax.swing.JTextField TextAge;
    private javax.swing.JTextField TextWeight;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JLabel lblAgeError;
    private javax.swing.JLabel lblAge_Label;
    private javax.swing.JLabel lblBMI_Label;
    private javax.swing.JLabel lblComment_Label;
    private javax.swing.JLabel lblHeight_Label;
    private javax.swing.JLabel lblIntensity;
    private javax.swing.JLabel lblIntensityLabel;
    private javax.swing.JLabel lblOutput;
    private javax.swing.JLabel lblWeightError;
    private javax.swing.JLabel lblWeight_Label;
    private javax.swing.JMenuBar menuMainMenu;
    private javax.swing.JPanel pnlBMI;
    private javax.swing.JPanel pnlHR;
    private javax.swing.JTabbedPane tpnlMainTabPanel;
    // End of variables declaration//GEN-END:variables
}
