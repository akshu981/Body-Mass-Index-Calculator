/*
Author: Akshayaa Shrestha
Date:01/14/2018
Description: Java application that calculates workout targeted heart rate and body max index via graphical user interface
*/
package MainPackage;


public class Program {

    
    public static void main(String[] args) {
        
        UI_Form form= new UI_Form();
        form.setVisible(true);
    }
    
}
